/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Menu, ArrowRight } from 'lucide-react';

const PROJECTS = [
  {
    id: '01',
    title: 'THE MONOLITH',
    client: 'DIGITAL MONOLITH SYSTEMS',
    year: '2024',
    service: 'STRATEGY / ARCHITECTURE',
    image: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?q=80&w=2070&auto=format&fit=crop',
  },
  {
    id: '02',
    title: 'NEURAL NEXUS',
    client: 'SYNTEX CORP',
    year: '2023',
    service: 'BRANDING / WEBGL',
    image: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?q=80&w=2070&auto=format&fit=crop',
  },
  {
    id: '03',
    title: 'VOID PROTOCOL',
    client: 'OMNI DYNAMICS',
    year: '2024',
    service: 'UX / UI / MOTION',
    image: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?q=80&w=2064&auto=format&fit=crop',
  },
  {
    id: '04',
    title: 'ECHO CHAMBER',
    client: 'RESONANCE AUDIO',
    year: '2022',
    service: 'SPATIAL DESIGN',
    image: 'https://images.unsplash.com/photo-1518640467707-6811f4a6ab73?q=80&w=2000&auto=format&fit=crop',
  },
  {
    id: '05',
    title: 'OBSIDIAN CORE',
    client: 'QUANTUM LOGISTICS',
    year: '2025',
    service: 'INDUSTRIAL DESIGN',
    image: 'https://images.unsplash.com/photo-1505506874110-6a7a6c9924cb?q=80&w=2070&auto=format&fit=crop',
  }
];

export default function App() {
  const [hoveredProject, setHoveredProject] = useState<string | null>(null);

  return (
    <div className="min-h-screen bg-black text-[#e2e2e2] selection:bg-[#FF3E00] selection:text-white relative font-['Inter']">
      {/* Background Image Reveal */}
      <div className="fixed inset-0 z-0 pointer-events-none transition-opacity duration-700 bg-black">
        <AnimatePresence>
          {hoveredProject && (
            <motion.div
              key={hoveredProject}
              initial={{ opacity: 0, scale: 1.05 }}
              animate={{ opacity: 0.3, scale: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
              className="absolute inset-0"
            >
              <img 
                src={PROJECTS.find(p => p.id === hoveredProject)?.image} 
                alt="Project Background" 
                className="w-full h-full object-cover grayscale"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-black opacity-80" />
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Header */}
      <header className="fixed top-0 w-full z-50 bg-black/50 backdrop-blur-md border-b-[0.5px] border-[#FF3E00]/20">
        <div className="flex justify-between items-center w-full px-6 py-4 max-w-[1440px] mx-auto">
          <div className="text-2xl font-black tracking-tighter text-[#FF3E00] font-['Space_Grotesk'] uppercase">
            VOID_ARCHITECTS
          </div>
          <nav className="hidden md:flex gap-8 font-['Space_Grotesk'] tracking-tighter uppercase font-bold text-sm">
            <a href="#" className="text-[#FF3E00] border-b-2 border-[#FF3E00] pb-1">PROJECTS</a>
            <a href="#" className="text-gray-400 hover:text-white transition-colors">STUDIO</a>
            <a href="#" className="text-gray-400 hover:text-white transition-colors">JOURNAL</a>
            <a href="#" className="text-gray-400 hover:text-white transition-colors">CONTACT</a>
          </nav>
          <div className="flex items-center gap-4">
            <button className="text-white hover:text-[#FF3E00] transition-all duration-300">
              <Menu size={24} />
            </button>
          </div>
        </div>
      </header>

      <main className="pt-40 pb-24 relative z-10">
        <div className="px-6 max-w-[1440px] mx-auto mb-24">
          <h1 className="font-['Space_Grotesk'] font-black text-5xl md:text-[8rem] lg:text-[10rem] leading-[0.85] tracking-tighter text-white uppercase">
            SELECTED <br />
            <span className="text-[#FF3E00]">WORKS_</span>
          </h1>
        </div>

        {/* Project List */}
        <div className="w-full border-t border-white/10 flex flex-col">
          {PROJECTS.map((project) => (
            <div 
              key={project.id}
              className="group relative border-b border-white/10 cursor-pointer overflow-hidden"
              onMouseEnter={() => setHoveredProject(project.id)}
              onMouseLeave={() => setHoveredProject(null)}
            >
              {/* Hover Accent Background */}
              <div className="absolute inset-0 bg-[#FF3E00] translate-y-full group-hover:translate-y-0 transition-transform duration-500 ease-[0.16,1,0.3,1] z-0" />

              <div className="px-6 py-10 md:py-16 max-w-[1440px] mx-auto flex flex-col md:flex-row md:items-center justify-between gap-6 md:gap-12 relative z-10">
                
                {/* Left: ID & Title */}
                <div className="flex flex-col md:flex-row md:items-baseline gap-4 md:gap-12 w-full md:w-2/3">
                  <span className="font-['Space_Grotesk'] font-bold text-[#FF3E00] group-hover:text-black text-xl md:text-2xl transition-colors duration-500">
                    {project.id}/
                  </span>
                  <h2 className="font-['Space_Grotesk'] font-black text-5xl md:text-7xl lg:text-[7rem] leading-[0.85] tracking-tighter uppercase transition-all duration-500 text-transparent [-webkit-text-stroke:1px_rgba(255,255,255,0.3)] group-hover:[-webkit-text-stroke:0px_transparent] group-hover:text-black">
                    {project.title}
                  </h2>
                </div>

                {/* Right: Metadata & Arrow */}
                <div className="flex items-center justify-between md:justify-end gap-8 w-full md:w-1/3">
                  <div className="flex flex-col gap-1 md:opacity-0 md:-translate-x-4 group-hover:opacity-100 group-hover:translate-x-0 transition-all duration-500 ease-out">
                    <p className="font-['Space_Grotesk'] text-xs tracking-[0.2em] text-gray-400 group-hover:text-black/70 uppercase">{project.client}</p>
                    <p className="font-['Inter'] text-sm text-white group-hover:text-black font-medium uppercase">{project.service}</p>
                  </div>
                  
                  <div className="w-12 h-12 rounded-full border border-white/20 group-hover:border-black flex items-center justify-center transition-all duration-500 shrink-0">
                    <ArrowRight className="text-white group-hover:text-black -rotate-45 group-hover:rotate-0 transition-transform duration-500" size={20} />
                  </div>
                </div>

              </div>
            </div>
          ))}
        </div>
      </main>

      {/* Footer */}
      <footer className="w-full border-t border-white/10 bg-black relative z-10">
        <div className="flex flex-col md:flex-row justify-between items-center px-6 py-12 w-full max-w-[1440px] mx-auto">
          <div className="text-lg font-black text-white font-['Space_Grotesk'] tracking-tighter uppercase mb-8 md:mb-0">
            VOID_ARCHITECTS
          </div>
          <div className="flex flex-wrap justify-center gap-6 md:gap-8 font-['Space_Grotesk'] text-[10px] tracking-[0.2em] uppercase">
            <a href="#" className="text-gray-600 hover:text-[#FF3E00] transition-colors duration-500">INSTAGRAM</a>
            <a href="#" className="text-gray-600 hover:text-[#FF3E00] transition-colors duration-500">LINKEDIN</a>
            <a href="#" className="text-gray-600 hover:text-[#FF3E00] transition-colors duration-500">LEGAL</a>
            <a href="#" className="text-gray-600 hover:text-[#FF3E00] transition-colors duration-500">PRIVACY</a>
          </div>
          <div className="mt-8 md:mt-0 font-['Space_Grotesk'] text-[10px] tracking-[0.2em] uppercase text-gray-600 text-center">
            ©2024 VOID_ARCHITECTS. ALL RIGHTS RESERVED.
          </div>
        </div>
      </footer>
    </div>
  );
}
